package com.example.Arun.booksController;

import java.io.File;
import java.net.URL;

import javax.net.ssl.SSLContext;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class HttpClient {
	public org.json.simple.JSONObject httpResponse(String ivrRequestID, String url, String requestType,
			org.json.simple.JSONObject jd, String apiurl, String apiname, String jkpath, String readTimeout,
			String connectionTimeout, String fetchTimeout) {
		org.json.simple.JSONObject finalJson = null;
		int responseCode = 0;
		HttpUriRequest request = null;

		try {

			String apiUserName = (String) apiname;
			String apiPassword = "";

			String jksPath = (String) jkpath;
			String jksPassword = "";

			int connectionTimeOut = Integer.parseInt(connectionTimeout.toString());
			int socketTimeOut = Integer.parseInt(fetchTimeout.toString());
			int readTimeOut = Integer.parseInt(readTimeout.toString());

			// System.out.println("ddd");

			RequestConfig config = RequestConfig.custom().setConnectTimeout(connectionTimeOut * 1000)
					.setSocketTimeout(socketTimeOut * 1000).setConnectionRequestTimeout(readTimeOut * 1000).build();

			HttpClientBuilder clientbuilder = HttpClients.custom();

			if ("https".equals(new URL(url).getProtocol())) {
				SSLContextBuilder SSLBuilder = SSLContexts.custom();
				File file = new File(new File(jksPath).getCanonicalPath());
				SSLBuilder = SSLBuilder.loadTrustMaterial(file, jksPassword.toCharArray());
				SSLContext sslcontext = SSLBuilder.build();
				SSLConnectionSocketFactory sslConSocFactory = new SSLConnectionSocketFactory(sslcontext,
						new NoopHostnameVerifier());
				clientbuilder = clientbuilder.setSSLSocketFactory(sslConSocFactory);

			} else {

			}

			if (!"NA".equalsIgnoreCase(apiUserName) && !"NA".equalsIgnoreCase(apiPassword)) {
				CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
				Credentials credentials = new UsernamePasswordCredentials(apiUserName, apiPassword);
				credentialsPovider.setCredentials(AuthScope.ANY, credentials);
				clientbuilder.setDefaultCredentialsProvider(credentialsPovider);
			} else {

			}

			if ("Get".equalsIgnoreCase(requestType)) {
				request = new HttpGet(url);
				request.setHeader("Content-Type", "application/json; charset=utf-8");
				request.setHeader("apirequestId", ivrRequestID);
			} else if ("Post".equalsIgnoreCase(requestType)) {
				request = new HttpPost(url);
				request.setHeader("Content-Type", "application/json; charset=utf-8");
				request.setHeader("apirequestId", ivrRequestID);
				((HttpPost) request).setEntity(new StringEntity(jd.toString(), "UTF-8"));
			} else {
				request = new HttpPut(url);
				request.setHeader("Content-Type", "application/json; charset=utf-8");
				request.setHeader("apirequestId", ivrRequestID);
				((HttpPut) request).setEntity(new StringEntity(jd.toString(), "UTF-8"));
			}

			try (CloseableHttpClient httpClient = clientbuilder.setDefaultRequestConfig(config).build();
					CloseableHttpResponse response = httpClient.execute(request)) {

				responseCode = response.getStatusLine().getStatusCode();

				if (200 == responseCode) {
					finalJson = (org.json.simple.JSONObject) new JSONParser()
							.parse(EntityUtils.toString(response.getEntity()));
					System.out.println("API CONNECTION SUCCESS WITH RESPONSE CODE: " + responseCode);
				} else {
					finalJson = (org.json.simple.JSONObject) new JSONParser()
							.parse(EntityUtils.toString(response.getEntity()));
					;
					System.out.println("API CONNECTION FAILURE WITH RESPONSE CODE: " + responseCode);
					System.out.println(finalJson.toString());
				}

			} catch (Exception e) {
				System.out.println(e);
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return finalJson;

	}
}

package com.example.Arun.booksController;


public class FlatFile_pojo {
	
	    private String billing_phone;
	    private String customer_email;
	    private String send_customer_email;
	    private String billing_name;
	    private String resident_id;
	    private String subCategoryDescription;
	    private String categoryDescription;
	    public String getResponseCode() {
			return responseCode;
		}
		public void setResponseCode(String responseCode) {
			this.responseCode = responseCode;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		private String responseCode;
	    private String message;
	    private String status;
	    private String responseBody;
		public String getBilling_phone() {
			return billing_phone;
		}
		public void setBilling_phone(String billing_phone) {
			this.billing_phone = billing_phone;
		}
		public String getCustomer_email() {
			return customer_email;
		}
		public void setCustomer_email(String customer_email) {
			this.customer_email = customer_email;
		}
		public String getSend_customer_email() {
			return send_customer_email;
		}
		public void setSend_customer_email(String send_customer_email) {
			this.send_customer_email = send_customer_email;
		}
		public String getBilling_name() {
			return billing_name;
		}
		public void setBilling_name(String billing_name) {
			this.billing_name = billing_name;
		}
		public String getResident_id() {
			return resident_id;
		}
		public void setResident_id(String resident_id) {
			this.resident_id = resident_id;
		}
		public String getSubCategoryDescription() {
			return subCategoryDescription;
		}
		public void setSubCategoryDescription(String subCategoryDescription) {
			this.subCategoryDescription = subCategoryDescription;
		}
		public String getCategoryDescription() {
			return categoryDescription;
		}
		public void setCategoryDescription(String categoryDescription) {
			this.categoryDescription = categoryDescription;
		}
		public String getResponseBody() {
			return responseBody;
		}
		public void setResponseBody(String responseBody) {
			this.responseBody = responseBody;
		}
	    

	}




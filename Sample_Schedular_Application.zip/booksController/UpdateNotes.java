package com.example.Arun.booksController;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;

public class UpdateNotes {
	Logger LOGGER = org.apache.logging.log4j.LogManager.getLogger(this.getClass());
	public List<FlatFile_pojo> updateNotes(org.json.simple.JSONObject jd, String apiurl, String apiname, String jkpath,
			String readTimeout, String connectionTimeout, String fetchTimeout) {
		HttpClient httpClient = new HttpClient();
		String methodName = "updateNotes";
		FlatFile_pojo fla = new FlatFile_pojo();

		List<FlatFile_pojo> all = new ArrayList<FlatFile_pojo>();
		try {
			// System.out.println("kkkkk");
			String url = apiurl + "external/" + methodName;

			String ivrRequestID = "10006752434325";

			String InternalResponseCode = null;
			String InternalStatus = null;
			String InternalMessage = null;
			String Internalreso = null;

			// System.out.println("kkkkk55");

			try {
				org.json.simple.JSONObject receviedpostCallHistoryResponse = httpClient.httpResponse(ivrRequestID, url,
						"Put", jd, apiurl, apiname, jkpath, readTimeout, connectionTimeout, fetchTimeout);

				if (receviedpostCallHistoryResponse == null) {
					LOGGER.info("http response is Null");
					fla.setResponseBody(null);
					fla.setResponseCode(null);
					fla.setMessage(null);
					fla.setStatus(null);
					all.add(fla);
				} else if (receviedpostCallHistoryResponse.get("status").toString().equalsIgnoreCase("Failure")) {
					fla.setStatus(receviedpostCallHistoryResponse.get("status").toString());
					fla.setResponseCode(receviedpostCallHistoryResponse.get("responseCode").toString());
				    fla.setResponseBody(receviedpostCallHistoryResponse.get("message").toString());
					fla.setMessage(null);
					all.add(fla);
				} else {

					InternalResponseCode = receviedpostCallHistoryResponse.get("responseCode").toString();
					InternalMessage = receviedpostCallHistoryResponse.get("message").toString();
					System.out.println(InternalResponseCode);
					Internalreso = receviedpostCallHistoryResponse.get("responseBody").toString();
					System.out.println(Internalreso);
					InternalStatus = receviedpostCallHistoryResponse.get("status").toString();
					fla.setResponseBody(Internalreso);
					fla.setResponseCode(InternalResponseCode);
					fla.setMessage(InternalMessage);
					fla.setStatus(InternalStatus);
					all.add(fla);

					if (InternalResponseCode.equalsIgnoreCase("000")) {
						InternalResponseCode = receviedpostCallHistoryResponse.get("responseCode").toString();
						InternalMessage = receviedpostCallHistoryResponse.get("message").toString();
						InternalStatus = receviedpostCallHistoryResponse.get("status").toString();
						System.out.println(InternalResponseCode);
						Internalreso = receviedpostCallHistoryResponse.get("responseBody").toString();
						System.out.println(Internalreso);
						fla.setResponseBody(Internalreso);
						fla.setResponseCode(InternalResponseCode);
						fla.setMessage(InternalMessage);
						fla.setStatus(InternalStatus);
						all.add(fla);

					} else {
						LOGGER.info("ERROR GETTING INTERNAL RESPONSE CODE AS '000'");
						System.out.println("ERROR GETTING INTERNAL RESPONSE CODE AS '000'");
						InternalResponseCode = receviedpostCallHistoryResponse.get("responseCode").toString();
						InternalMessage = receviedpostCallHistoryResponse.get("message").toString();
						System.out.println(InternalResponseCode);
						Internalreso = receviedpostCallHistoryResponse.get("responseBody").toString();
						System.out.println(Internalreso);
						fla.setResponseBody(Internalreso);
						InternalStatus = receviedpostCallHistoryResponse.get("status").toString();
						fla.setResponseCode(InternalResponseCode);
						fla.setMessage(InternalMessage);
						fla.setStatus(InternalStatus);
						all.add(fla);
					}

				}

			} catch (Exception e) {

				System.out.println("error88");
				System.out.println(e);
			}
		} catch (Exception e) {
			System.out.println("error");
			System.out.println(e);
		}

		return all;
	}
}

package com.example.Arun.booksController;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class Starnik_FlatFile {
	Logger LOGGER = org.apache.logging.log4j.LogManager.getLogger(this.getClass());
	// @Scheduled(cron = "0 0
	@Value("${jdbc.url}")
	private String jdbcUrl;

	@Scheduled(cron = "${cronExpression}")
	public String starNik_File() throws IOException, ParseException, JSONException {
		LOGGER.info("APPLICATION STARTED");
		UpdateNotes notes = new UpdateNotes();
		FlatFile_pojo flat = new FlatFile_pojo();
		JSONParser jp = new JSONParser();
		Object obj = jp.parse(new FileReader(jdbcUrl));
		JSONObject jsonObject = (JSONObject) obj;
		Object f = jsonObject.get("FlatFileLocation");
		System.out.println(f.toString());
		JSONObject j = (JSONObject) f;
		Object ob = j.get("fileLocation");
		System.out.println(ob.toString());
		Object apiurl = j.get("apiurl");
		Object apiname = j.get("apiUserName");
		Object jkpath = j.get("jksFilePath");
		Object readTimeout = j.get("readTimeOut");
		Object connectionTimeout = j.get("connectionTimeOut");
		Object fetchTimeout = j.get("fetchTimeOut");
		System.out.println(apiurl.toString());
		File file = new File(ob.toString());
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		System.out.println(formatter.format(date).toString());
		String fileApp = file.toString() + "05-04-2023.json";
		System.out.println(fileApp);
		File file1 = new File(fileApp);
		BufferedReader reader;
		List<String> timeout = new ArrayList<String>();
		int SuccessCount = 0;

		int FailureCount = 0;

		int TimeoutCount = 0;
		int count = 0;
		if (file1.exists()) {
			String pathToFile = fileApp;
			BufferedReader someReader = new BufferedReader(new FileReader(file1));
			String someData;
			while ((someData = someReader.readLine()) != null) {

				JSONObject json = (JSONObject) jp.parse(someData);

				// System.out.println( json.size());
				Object ss = json.get("billing_phone");
				flat.setBilling_phone(ss.toString());
				System.out.println(flat.getBilling_phone());
				// System.out.println(ss.toString());
				Object bn = json.get("billing_name");
				// System.out.println(bn.toString());
				flat.setBilling_name(bn.toString());
				Object email = json.get("customer_email");
				flat.setCustomer_email(email.toString());
				Object sendemail = json.get("send_customer_email");
				flat.setSend_customer_email(sendemail.toString());
				Object id = json.get("resident_id");
				flat.setResident_id(id.toString());
				Object sd = json.get("subCategoryDescription");
				flat.setSubCategoryDescription(sd.toString());
				Object ca = json.get("categoryDescription");// *
				flat.setCategoryDescription(ca.toString());
				System.out.println("-------------------");
				HashMap<String, String> starnikUpdate = new HashMap<String, String>();

				starnikUpdate.put("resident_id", flat.getResident_id());
				starnikUpdate.put("billing_phone", flat.getBilling_phone());
				starnikUpdate.put("billing_name", flat.getBilling_name());
				starnikUpdate.put("customer_email", flat.getCustomer_email());
				starnikUpdate.put("send_customer_email", flat.getSend_customer_email());
				starnikUpdate.put("categoryDescription", flat.getCategoryDescription());
				starnikUpdate.put("subCategoryDescription", flat.getSubCategoryDescription());
				System.out.println(starnikUpdate.toString());

				JSONObject jd = new JSONObject();
				jd.putAll(starnikUpdate);

				List<FlatFile_pojo> allcodes = notes.updateNotes(jd, apiurl.toString(), apiname.toString(),
						jkpath.toString(), readTimeout.toString(), connectionTimeout.toString(),
						fetchTimeout.toString());

				for (int i = 0; i < allcodes.size(); i++) {
					System.out.println(allcodes.size());
					String responsecode = allcodes.get(i).getResponseCode();
					String responseBody = allcodes.get(i).getResponseBody();
					String responsemessage = allcodes.get(i).getStatus();
					System.out.println(responsecode + "hhhh");
					System.out.println(responseBody);
					if (responsecode == null) {
						TimeoutCount++;
						LOGGER.info("RESPONSE IS NULL BECAUSE OF TIME OUT");
				
						timeout.add(jd.toString());
						System.out.println(timeout.toString());
					} else {
						if (responsecode.equalsIgnoreCase("000")) {
							SuccessCount++;
							System.out.println("EVERYTHING WORKS FINE");
							LOGGER.info("THIS RESPONSE GETS RESPONSE :000");
							LOGGER.info("SUCCESS RESPONSE--->");
							LOGGER.info(responseBody);
							LOGGER.info("APPLICATION RUNNING SUCCESSFULLY");
							break;
						} else if (responsecode != "000" && responsemessage.equals("Failure")) {
							FailureCount++;
							LOGGER.info("THIS RESPONSE IS FAILURE RESPONSE");
							LOGGER.info(responseBody);
							timeout.add(jd.toString());
							System.out.println(timeout.toString());
						}
						System.out.println("true");
					}
				}

			}

			if (timeout != null) {
				for (int i = 0; i < timeout.size(); i++) {
					JSONParser parser = new JSONParser();
					JSONObject json = (JSONObject) parser.parse(timeout.get(i));
					List<FlatFile_pojo> allcodess = notes.updateNotes(json, apiurl.toString(), apiname.toString(),
							jkpath.toString(), readTimeout.toString(), connectionTimeout.toString(),
							fetchTimeout.toString());
					LOGGER.info("THESE ARE TIMEOUT AND FAILURE  RESPONSES");
					String responsBody;
					String responssCode;
					String responseemessag;
					String responseboddy;
					for (int y = 0; y < allcodess.size(); y++) {
						responsBody = allcodess.get(y).getResponseBody();
						responssCode = allcodess.get(y).getResponseCode();
						responseemessag = allcodess.get(i).getStatus();
						LOGGER.info(responsBody);
						if (responssCode != "000" && responseemessag.equalsIgnoreCase("Failure") && count < 2) {
							count++;
							JSONParser parsers = new JSONParser();
							JSONObject jsons = (JSONObject) parsers.parse(timeout.get(i));
							List<FlatFile_pojo> allcodesss = notes.updateNotes(jsons, apiurl.toString(),
									apiname.toString(), jkpath.toString(), readTimeout.toString(),
									connectionTimeout.toString(), fetchTimeout.toString());
							responseboddy = allcodesss.get(y).getResponseBody();
							LOGGER.info(responseboddy);
						}

						break;
					}

				}
				
			}
			System.out.println(SuccessCount);
			LOGGER.info("SUCCESS RESPONSE COUNT:  " + SuccessCount);
			LOGGER.info("FAILURE RESPONSE THAT RESOLVED COUNT:  " + FailureCount);
			LOGGER.info("TIMEOUT RESPONSE THAT RESOLVED COUNT:  " + TimeoutCount);
			LOGGER.info("APPLICATION ENDED");

		} else {
			LOGGER.info("THERE IS NO STARNIK FLAT FILE FOR THIS DATE");
			System.out.println("There is no Starnik  Flat file for this Date");
			System.out.println("false");
		}
		return fileApp;

	}
}
